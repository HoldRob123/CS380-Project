create definer = root@localhost trigger trg_after_vehicle_delete
    after delete
    on vehicles
    for each row
BEGIN
    IF OLD.userID IS NOT NULL THEN
        DELETE FROM saved_vehicles
        WHERE user_id = OLD.userID AND vin_number = OLD.VIN_NUMBER;
    END IF;
END;

