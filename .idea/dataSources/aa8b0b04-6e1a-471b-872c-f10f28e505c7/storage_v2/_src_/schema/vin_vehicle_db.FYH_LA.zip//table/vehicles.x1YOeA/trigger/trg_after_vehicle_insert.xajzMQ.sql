create definer = root@localhost trigger trg_after_vehicle_insert
    after insert
    on vehicles
    for each row
BEGIN
    IF NEW.userID IS NOT NULL THEN
        INSERT IGNORE INTO saved_vehicles (user_id, vin_number)
        VALUES (NEW.userID, NEW.VIN_NUMBER);
    END IF;
END;

